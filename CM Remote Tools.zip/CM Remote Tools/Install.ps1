﻿# Script to install the Configuration Manager Remote Tools client standalone
# Jorgen@ccmexec.com 
# ccmexec.com
#
# Variable with the Primary Site Server Name

$SCCMSiteServer = "SCCM01.eklient.lab"

$Installdir = "$env:ProgramFiles\CMremoteControl"
New-Item -Path $Installdir -ItemType Directory
New-Item -Path "$Installdir\00000409" -ItemType Directory

Copy-Item -Path "$PSScriptRoot\RdpCoreSccm.dll" -Destination $Installdir
Copy-Item -Path "$PSScriptRoot\CmRcViewer.exe" -Destination $Installdir
Copy-item -Path "$PSScriptRoot\00000409\CmRcViewerRes.dll" -Destination $installdir\00000409

If ([Environment]::Is64BitOperatingSystem) {
    New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\ConfigMgr10" -type Directory
    New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\ConfigMgr10\AdminUI" -type Directory
    New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\ConfigMgr10\AdminUI\Connection" -type Directory
    new-itemproperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\ConfigMgr10\AdminUI\Connection" -Name "Server" -Value $SCCMSiteServer -PropertyType String -Force 
   }  
Else {
    New-Item -Path "HKLM:\SOFTWARE\Microsoft\ConfigMgr10" -type Directory
    New-Item -Path "HKLM:\SOFTWARE\Microsoft\ConfigMgr10\AdminUI" -type Directory
    New-Item -Path "HKLM:\SOFTWARE\Microsoft\ConfigMgr10\AdminUI\Connection" -type Directory
    new-itemproperty "HKLM:\SOFTWARE\Microsoft\ConfigMgr10\AdminUI\Connection" -Name "Server" -Value $SCCMSiteServer -PropertyType String -Force 
} 
# Create a Shortcut with Windows PowerShell
$TargetFile = "$installdir\cmrcviewer.exe"
$ShortcutFile = "$Env:ProgramData\Microsoft\Windows\Start Menu\Remote control.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $TargetFile
$Shortcut.Save()
