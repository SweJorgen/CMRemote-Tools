﻿# Script to install the Configuration Manager Remote Tools client standalone
# Jorgen@ccmexec.com 
# ccmexec.com

$Installdir = "$env:ProgramFiles\CMremoteControl"
Remove-Item -Path $Installdir -Recurse -Force
If ([Environment]::Is64BitOperatingSystem) {
    Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\ConfigMgr10" -Recurse -Force
   }  
Else {
    Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\ConfigMgr10" -Recurse -Force
}
Remove-Item -Path "$Env:ProgramData\Microsoft\Windows\Start Menu\Remote control.lnk" -Force
